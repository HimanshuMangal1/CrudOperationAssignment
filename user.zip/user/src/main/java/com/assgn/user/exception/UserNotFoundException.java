package com.assgn.user.exception;

/**
 * Custom exception class who throw the exception when user is not found in any case.
 * @author AG20153
 *
 */
public class UserNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public UserNotFoundException(int id) {
        super("User id not found : " + id);
    }

}
