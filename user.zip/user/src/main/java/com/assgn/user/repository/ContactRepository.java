package com.assgn.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.assgn.user.entity.Contact;

@Repository
public interface ContactRepository extends JpaRepository<Contact, Long> {

}
