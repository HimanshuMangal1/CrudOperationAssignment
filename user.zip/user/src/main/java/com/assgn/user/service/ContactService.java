package com.assgn.user.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assgn.user.entity.Contact;
import com.assgn.user.entity.User;
import com.assgn.user.exception.UserNotFoundException;
import com.assgn.user.repository.ContactRepository;

@Service
public class ContactService {
	
	@Autowired
	private ContactRepository contactRepository;
	
	/**
	 * 
	 * @param contact
	 * @return
	 */
	public Contact addUser(Contact contact) {
		return contactRepository.save(contact);
	}

	/**
	 * 
	 * @return List of contact
	 */
	public List<Contact> getAllContact() {
		return contactRepository.findAll();
	}

	
	

	


}
