package com.assgn.user.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Contact {

	@Id
	@Column(name = "mobileNumber")
	private Long mobileNumber;

	@Column(name = "assress_Line1")
	private String assress_Line1;

	@Column(name = "assress_Line2")
	private String assress_Line2;

	public Contact() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Contact(Long mobileNumber, String assress_Line1, String assress_Line2) {
		super();
		this.mobileNumber = mobileNumber;
		this.assress_Line1 = assress_Line1;
		this.assress_Line2 = assress_Line2;
	}

	public Long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getAssress_Line1() {
		return assress_Line1;
	}

	public void setAssress_Line1(String assress_Line1) {
		this.assress_Line1 = assress_Line1;
	}

	public String getAssress_Line2() {
		return assress_Line2;
	}

	public void setAssress_Line2(String assress_Line2) {
		this.assress_Line2 = assress_Line2;
	}

	@Override
	public String toString() {
		return "Contact [mobileNumber=" + mobileNumber + ", assress_Line1=" + assress_Line1 + ", assress_Line2="
				+ assress_Line2 + "]";
	}

}
