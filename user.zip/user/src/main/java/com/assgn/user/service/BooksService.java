package com.assgn.user.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assgn.user.entity.Books;
import com.assgn.user.exception.UserNotFoundException;
import com.assgn.user.repository.BooksRepository;

@Service
public class BooksService {
	
	
	@Autowired
	private BooksRepository booksRepository;
	
	
	/**
	 * 
	 * @param books
	 * @return
	 */
	public Books addBooks(Books books) {
		return booksRepository.save(books);
	}

	/**
	 * 
	 * @return List of books
	 */
	public List<Books> getAllBooks() {
		return booksRepository.findAll();
	}

	/**
	 * 
	 * @param id
	 * @return Books Object
	 */
	public Optional<Books> getBooksById(int id) {
		return booksRepository.findById(id);
	}

	/**
	 * 
	 * @param id
	 */
	public void deleteBooks(int id) {
		booksRepository.deleteById(id);
	}

	/**
	 * 
	 * @param id
	 * @param books
	 * @return
	 */
	public Books updateBooks(int id, Books books) {
		Optional<Books> updateOpt = booksRepository.findById(id);
		Books booksInDb = null;
		if (updateOpt.isPresent()) {
			booksInDb = updateOpt.get();
			booksInDb.setId(id);
			booksInDb.setName(books.getName());
			booksInDb.setPrice(books.getPrice());
			booksInDb.setCurrency(books.getCurrency());
			booksRepository.save(booksInDb);
			return booksInDb;

		} else {
			throw new UserNotFoundException(id);
		}

	}


}
