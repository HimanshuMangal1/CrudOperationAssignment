package com.assgn.user.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assgn.user.entity.User;
import com.assgn.user.exception.UserNotFoundException;
import com.assgn.user.repository.UserRepository;

@Service
public class UserService {
	
	@Autowired
	private UserRepository userRepository;

	/**
	 * @param user
	 * @return the newly created user by request.
	 */
	public User addUser(User newUser) {
		return userRepository.save(newUser);
	}

	/**
	 * 
	 * @return the list of all user by request.
	 */
	public List<User> getAllUser() {
		return userRepository.findAll();
	}

	/**
	 * @param id
	 * @return the User by request.
	 */
	public Optional<User> getUserById(int id) {
		return userRepository.findById(id);
	}

	/**
	 * @param id
	 * @delete the User by request.
	 */
	public void deleteUser(int id) {
		userRepository.deleteById(id);
	}

	/**
	 * 
	 * @param user,id
	 * @return the newly created user by request.
	 */
	public User updateUser(int id, User user) {
		Optional<User> updateOpt = userRepository.findById(id);
		User userInDb = null;
		if (updateOpt.isPresent()) {
			userInDb = updateOpt.get();
			userInDb.setId(id);
			userInDb.setEmail(user.getEmail());
			userInDb.setFirstName(user.getFirstName());
			userInDb.setLastName(user.getLastName());
			userInDb.setUserName(user.getUserName());
			userInDb.setContact(user.getContact());
			userInDb.setBooks(user.getBooks());
			userRepository.save(userInDb);
			return userInDb;

		} else {
			throw new UserNotFoundException(id);
		}

	}



}
